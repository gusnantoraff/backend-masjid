"use client";
import React, { ReactNode, useEffect, useState } from "react";
import Loader from "@/components/common/Loader";
import "@/css/login.css"

export default function AuthLayout({ children }: { children: ReactNode }) {
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    const timeout = setTimeout(() => setLoading(false), 1000);
    return () => clearTimeout(timeout); // Bersihkan timeout
  }, []);

  return (
    <html lang="en">
      <body suppressHydrationWarning={true}>
          {loading ? <Loader /> : children}
      </body>
    </html>
  );
}
